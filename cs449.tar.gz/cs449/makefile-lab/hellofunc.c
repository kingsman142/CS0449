#include <stdio.h>
#include "hellomake.h"

void myPrintHelloMake(void){
	printf("Hello makefiles!\n");
	return;
}
